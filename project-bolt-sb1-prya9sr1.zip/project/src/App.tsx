import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import FilterSidebar from './components/FilterSidebar';
import CarListings from './components/CarListings';
import Breadcrumb from './components/Breadcrumb';
import AdvancedFilters from './components/AdvancedFilters';
import SearchResults from './components/SearchResults';

interface SearchCriteria {
  color?: string;
  priceMin?: number;
  priceMax?: number;
  fuelType?: string;
  mileage?: number;
  year?: number;
}

function App() {
  const [showHero, setShowHero] = useState(true);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [searchCriteria, setSearchCriteria] = useState<SearchCriteria>({});
  const [searchFilters, setSearchFilters] = useState({
    mileage: '',
    priceMin: '',
    priceMax: '',
    year: '',
    fuelType: ''
  });

  const breadcrumbItems = [
    { label: 'Acasă', href: '#', onClick: () => setShowHero(true) },
    { label: 'Autoturisme', active: true }
  ];

  const handleSearch = () => {
    // Build search criteria from form inputs
    const criteria: SearchCriteria = {
      color: 'albastru', // Always blue as specified
    };

    if (searchFilters.priceMin) criteria.priceMin = parseInt(searchFilters.priceMin);
    if (searchFilters.priceMax) criteria.priceMax = parseInt(searchFilters.priceMax);
    if (searchFilters.fuelType) criteria.fuelType = searchFilters.fuelType;
    if (searchFilters.mileage) criteria.mileage = parseInt(searchFilters.mileage);
    if (searchFilters.year) criteria.year = parseInt(searchFilters.year);

    setSearchCriteria(criteria);
    setShowSearchResults(true);
    setShowHero(false);
    setShowAdvancedFilters(false);

    // Update URL with search parameters
    const params = new URLSearchParams();
    params.set('color', 'albastru');
    if (criteria.priceMin) params.set('priceMin', criteria.priceMin.toString());
    if (criteria.priceMax) params.set('priceMax', criteria.priceMax.toString());
    if (criteria.fuelType) params.set('fuelType', criteria.fuelType);
    if (criteria.mileage) params.set('mileage', criteria.mileage.toString());
    if (criteria.year) params.set('year', criteria.year.toString());
    
    window.history.pushState({}, '', `?${params.toString()}`);
  };

  const resetToListings = () => {
    setShowSearchResults(false);
    setShowHero(false);
    setShowAdvancedFilters(false);
    window.history.pushState({}, '', window.location.pathname);
  };

  const resetToHome = () => {
    setShowHero(true);
    setShowSearchResults(false);
    setShowAdvancedFilters(false);
    window.history.pushState({}, '', window.location.pathname);
  };

  if (showAdvancedFilters) {
    return <AdvancedFilters onBack={resetToListings} onHome={resetToHome} />;
  }

  if (showSearchResults) {
    return <SearchResults criteria={searchCriteria} onHome={resetToHome} onBack={resetToListings} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onHome={resetToHome} />
      
      {showHero ? (
        <HeroSection onAdvancedFilters={() => setShowAdvancedFilters(true)} />
      ) : (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb items={breadcrumbItems} />
          
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Autoturisme</h1>
          </div>
          
          {/* Search Section */}
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6">
              {/* Mileage */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Rulaj (km)
                </label>
                <input
                  type="number"
                  placeholder="ex. 50000"
                  value={searchFilters.mileage}
                  onChange={(e) => setSearchFilters(prev => ({ ...prev, mileage: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>

              {/* Price Range */}
              <div className="sm:col-span-2 lg:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preț (EUR)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={searchFilters.priceMin}
                    onChange={(e) => setSearchFilters(prev => ({ ...prev, priceMin: e.target.value }))}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={searchFilters.priceMax}
                    onChange={(e) => setSearchFilters(prev => ({ ...prev, priceMax: e.target.value }))}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                </div>
              </div>

              {/* Year of Manufacture */}
              <div className="sm:col-span-2 lg:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  An fabricație
                </label>
                <select 
                  value={searchFilters.year}
                  onChange={(e) => setSearchFilters(prev => ({ ...prev, year: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white"
                >
                  <option value="">Selectează anul</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                  <option value="2017">2017</option>
                  <option value="2016">2016</option>
                  <option value="2015">2015</option>
                  <option value="2014">2014</option>
                  <option value="2013">2013</option>
                  <option value="2012">2012</option>
                  <option value="2011">2011</option>
                  <option value="2010">2010</option>
                  <option value="older">Mai vechi de 2010</option>
                </select>
              </div>

              {/* Fuel Type */}
              <div className="sm:col-span-2 lg:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Combustibil
                </label>
                <select 
                  value={searchFilters.fuelType}
                  onChange={(e) => setSearchFilters(prev => ({ ...prev, fuelType: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white"
                >
                  <option value="">Selectează combustibilul</option>
                  <option value="Benzină">Benzină</option>
                  <option value="Diesel">Diesel</option>
                  <option value="Hibrid">Hibrid</option>
                  <option value="Electric">Electric</option>
                  <option value="GPL">GPL</option>
                  <option value="CNG">CNG</option>
                </select>
              </div>
            </div>

            {/* Filter Button */}
            <div className="flex justify-center">
              <button
                onClick={handleSearch}
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-medium inline-flex items-center justify-center transition-colors duration-200"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707v4.586a1 1 0 01-.293.707l-2 2A1 1 0 0111 21v-6.586a1 1 0 00-.293-.707L4.293 7.293A1 1 0 014 6.586V4z" />
                </svg>
                Caută Autoturisme Albastre
              </button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            <FilterSidebar />
            <CarListings />
          </div>
        </div>
      )}
      
      {/* Toggle Button for Demo */}
      <div className="fixed bottom-4 right-4 flex flex-col gap-2 z-50">
        <button
          onClick={() => setShowAdvancedFilters(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
        >
          Filtre Avansate
        </button>
        <button
          onClick={resetToHome}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg shadow-lg text-sm"
        >
          Acasă
        </button>
      </div>
    </div>
  );
}

export default App;