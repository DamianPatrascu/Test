import React, { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';

const FilterSidebar = () => {
  const [searchFilter, setSearchFilter] = useState('');
  const [selectedFilters, setSelectedFilters] = useState({
    availability: '',
    brand: '',
    model: '',
    fuel: '',
    region: ''
  });

  return (
    <div className="w-full lg:w-80 bg-white p-6 rounded-lg shadow-sm border">
      <h3 className="text-lg font-semibold mb-6">Căutare</h3>
      
      {/* Search Input */}
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Salvează căutare"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 pr-10"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-6">
        {/* Availability */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Disponibilitate
          </label>
          <div className="relative">
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white">
              <option value="">Selectează</option>
              <option value="in-stoc">În stoc</option>
              <option value="la-comanda">La comandă</option>
              <option value="rezervat">Rezervat</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {/* Brand */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Marcă
          </label>
          <div className="relative">
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white">
              <option value="">Selectează</option>
              <option value="audi">Audi</option>
              <option value="bmw">BMW</option>
              <option value="mercedes">Mercedes-Benz</option>
              <option value="volkswagen">Volkswagen</option>
              <option value="toyota">Toyota</option>
              <option value="honda">Honda</option>
              <option value="ford">Ford</option>
              <option value="opel">Opel</option>
              <option value="renault">Renault</option>
              <option value="skoda">Škoda</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {/* Model */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Model
          </label>
          <div className="relative">
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white">
              <option value="">Selectează</option>
              <option value="a4">A4</option>
              <option value="a6">A6</option>
              <option value="q5">Q5</option>
              <option value="serie3">Serie 3</option>
              <option value="serie5">Serie 5</option>
              <option value="glc">GLC</option>
              <option value="passat">Passat</option>
              <option value="golf">Golf</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {/* Fuel */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Combustibil
          </label>
          <div className="relative">
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white">
              <option value="">Selectează</option>
              <option value="benzina">Benzină</option>
              <option value="diesel">Diesel</option>
              <option value="hybrid">Hibrid</option>
              <option value="electric">Electric</option>
              <option value="gpl">GPL</option>
              <option value="cng">CNG</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {/* Region */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Județ/Regiune
          </label>
          <div className="relative">
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white">
              <option value="">Selectează</option>
              <option value="bucuresti">București</option>
              <option value="cluj">Cluj</option>
              <option value="timis">Timiș</option>
              <option value="constanta">Constanța</option>
              <option value="iasi">Iași</option>
              <option value="brasov">Brașov</option>
              <option value="galati">Galați</option>
              <option value="gorj">Gorj</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;