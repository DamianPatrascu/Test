import React, { useState } from 'react';
import { Search, ChevronDown, ChevronUp, X, Filter } from 'lucide-react';
import Header from './Header';
import Breadcrumb from './Breadcrumb';

interface AdvancedFiltersProps {
  onBack?: () => void;
  onHome?: () => void;
}

interface FilterState {
  search: string;
  availability: string;
  brand: string;
  model: string;
  fuel: string;
  region: string;
  locality: string;
  category: string[];
  condition: string;
  gearbox: string;
  seller: string;
  yearMin: string;
  yearMax: string;
  mileageMin: string;
  mileageMax: string;
  priceMin: string;
  priceMax: string;
  tva: string;
  discount: string;
  cylinderMin: string;
  cylinderMax: string;
  powerMin: string;
  powerMax: string;
  exterior: string[];
  interior: string[];
  interiorMaterial: string;
  // Equipment sections
  mainEquipment: string[];
  safetyEquipment: string[];
  comfortEquipment: string[];
  otherEquipment: string[];
  // Additional filters
  headlights: string;
  autopilot: string;
  climate: string;
  trailerCoupling: string;
  parkingAssist: string;
  repairKit: string;
  airbag: string;
  radio: string;
  emissionLabel: string;
}

const AdvancedFilters: React.FC<AdvancedFiltersProps> = ({ onBack, onHome }) => {
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    availability: '',
    brand: '',
    model: '',
    fuel: '',
    region: '',
    locality: '',
    category: [],
    condition: '',
    gearbox: '',
    seller: '',
    yearMin: '',
    yearMax: '',
    mileageMin: '0',
    mileageMax: '180000',
    priceMin: '',
    priceMax: '',
    tva: '',
    discount: '',
    cylinderMin: '',
    cylinderMax: '',
    powerMin: '',
    powerMax: '',
    exterior: [],
    interior: [],
    interiorMaterial: '',
    mainEquipment: [],
    safetyEquipment: [],
    comfortEquipment: [],
    otherEquipment: [],
    headlights: '',
    autopilot: '',
    climate: '',
    trailerCoupling: '',
    parkingAssist: '',
    repairKit: '',
    airbag: '',
    radio: '',
    emissionLabel: ''
  });

  const [expandedSections, setExpandedSections] = useState({
    mainEquipment: false,
    safetyEquipment: false,
    comfortEquipment: false,
    otherEquipment: false,
    exterior: false,
    interior: false
  });

  const breadcrumbItems = [
    { label: 'Acasă', href: '#', onClick: onHome },
    { label: 'Autoturisme', href: '#' },
    { label: 'Căutare avansată', active: true }
  ];

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleCheckboxChange = (category: keyof FilterState, value: string) => {
    setFilters(prev => {
      const currentValues = prev[category] as string[];
      const newValues = currentValues.includes(value)
        ? currentValues.filter(v => v !== value)
        : [...currentValues, value];
      return { ...prev, [category]: newValues };
    });
  };

  const handleInputChange = (field: keyof FilterState, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const clearAllFilters = () => {
    setFilters({
      search: '',
      availability: '',
      brand: '',
      model: '',
      fuel: '',
      region: '',
      locality: '',
      category: [],
      condition: '',
      gearbox: '',
      seller: '',
      yearMin: '',
      yearMax: '',
      mileageMin: '0',
      mileageMax: '180000',
      priceMin: '',
      priceMax: '',
      tva: '',
      discount: '',
      cylinderMin: '',
      cylinderMax: '',
      powerMin: '',
      powerMax: '',
      exterior: [],
      interior: [],
      interiorMaterial: '',
      mainEquipment: [],
      safetyEquipment: [],
      comfortEquipment: [],
      otherEquipment: [],
      headlights: '',
      autopilot: '',
      climate: '',
      trailerCoupling: '',
      parkingAssist: '',
      repairKit: '',
      airbag: '',
      radio: '',
      emissionLabel: ''
    });
  };

  const categories = [
    { id: 'cabrio', label: 'Cabrio', icon: '🚗' },
    { id: 'sport', label: 'Sport / Coupe', icon: '🏎️' },
    { id: 'compact', label: 'Compactă', icon: '🚙' },
    { id: 'berlina', label: 'Berlină', icon: '🚘' },
    { id: 'break', label: 'Break', icon: '🚐' },
    { id: 'suv', label: 'SUV', icon: '🚙' },
    { id: 'van', label: 'VAN / Minibus', icon: '🚐' },
    { id: 'alte', label: 'Alte clase', icon: '🚗' }
  ];

  const mainEquipmentOptions = [
    'Suspensie pneumatică', 'Încălzire auxiliară', 'Tracțiune 4x4',
    'Plafon panoramic din sticlă', 'Trapă decapotabilă'
  ];

  const safetyEquipmentOptions = [
    'ABS', 'Monitor unghi mort', 'Ceasuri bord digitale',
    'Oglinda retrovizoare cu întunnecare automată', 'Avertizare în caz de accident',
    'Apelare automată în caz de urgență', 'ESP', 'Avertizare în caz de oboseală',
    'Proiectoare ceață', 'Asistență la pornirea din rampă', 'Isofix',
    'Asistență schimbare bandă', 'Senzor de lumini', 'Night vision',
    'Isofix scaun pasager', 'Servodirecție', 'Monitorizare presiune anvelope',
    'Sistem de control al tracțiunii', 'Recunoaștere semne rutiere'
  ];

  const comfortEquipmentOptions = [
    'Geamuri electrice', 'Rabatare scaun pasager', 'Faruri cu faza lungă fără orbire',
    'Set pentru mâini libere', 'Sistem de spălare faruri', 'Head up display',
    'Volan încălzit', 'Parbriz încălzit', 'Asistență pentru faza lungă',
    'Streaming muzical integrat', 'Intrare fără cheie', 'Volan din piele',
    'Suport lombar', 'Scaune cu masaj', 'Volan multifuncțional',
    'Sistem de navigație', 'Volan cu padele', 'Filtru de particule',
    'Sistem de control al vitezei', 'Scaune sport', 'Touchscreen',
    'TV', 'Port USB', 'Scaune ventilate', 'Control vocal',
    'WLAN / Wi-Fi hotspot', 'Încărcare telefon wireless'
  ];

  const otherEquipmentOptions = [
    'Sistem de alarmă', 'Jante de aliaj', 'Anvelope All season',
    'Compatibil cu biodiesel', 'Separator portbagaj', 'Pentru persoane cu dizabilități',
    'Compatibil E10', 'Manual de service', 'ITP nou', 'Plug-in hybrid',
    'Dispozitiv antidemaraj electric', 'Vehicul pentru nefumători',
    'Computer de bord', 'Suspensie sport', 'Sine portbagaj plafon',
    'Husă pentru schiuri', 'Pachet fumători', 'Pachet sport',
    'Sistem de pornire/oprire automată', 'Jante de oțel', 'Anvelope de vară',
    'Taxi', 'Compatibil cu ulei vegetal', 'Garanție', 'Pachet de iarnă',
    'Anvelope de iarnă'
  ];

  const exteriorColors = [
    'Alb', 'Albastru', 'Argintiu', 'Auriu', 'Bej', 'Galben',
    'Gri', 'Maro', 'Negru', 'Portocaliu', 'Roșu', 'Verde', 'Violet'
  ];

  const interiorColors = [
    'Albastru', 'Bej', 'Gri', 'Maro', 'Negru', 'Roșu', 'Altele'
  ];

  const interiorMaterials = [
    'Alcantara', 'Catifea', 'Parțial piele', 'Piele ecologică', 'Piele integrală', 'Textil'
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Breadcrumb items={breadcrumbItems} />
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Căutare avansată</h1>
          <p className="text-gray-600">Folosește filtrele de mai jos pentru a găsi mașina perfectă</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6">
          {/* Search and Save */}
          <div className="mb-8">
            <div className="flex gap-4 mb-4">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Căutare"
                  value={filters.search}
                  onChange={(e) => handleInputChange('search', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 pr-10"
                />
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
              <button className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                <Search className="w-4 h-4" />
                Salvează căutare
              </button>
            </div>
          </div>

          {/* Basic Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {/* Disponibilitate */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Disponibilitate</label>
              <select 
                value={filters.availability}
                onChange={(e) => handleInputChange('availability', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="in-stoc">În stoc</option>
                <option value="la-comanda">La comandă</option>
                <option value="rezervat">Rezervat</option>
              </select>
            </div>

            {/* Marcă */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Marcă</label>
              <select 
                value={filters.brand}
                onChange={(e) => handleInputChange('brand', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="audi">Audi</option>
                <option value="bmw">BMW</option>
                <option value="mercedes">Mercedes-Benz</option>
                <option value="volkswagen">Volkswagen</option>
                <option value="toyota">Toyota</option>
                <option value="honda">Honda</option>
                <option value="ford">Ford</option>
                <option value="opel">Opel</option>
                <option value="renault">Renault</option>
                <option value="skoda">Škoda</option>
              </select>
            </div>

            {/* Model */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
              <select 
                value={filters.model}
                onChange={(e) => handleInputChange('model', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-gray-100"
              >
                <option value="">Selectează</option>
                <option value="a4">A4</option>
                <option value="a6">A6</option>
                <option value="q5">Q5</option>
                <option value="serie3">Serie 3</option>
                <option value="serie5">Serie 5</option>
                <option value="glc">GLC</option>
                <option value="passat">Passat</option>
                <option value="golf">Golf</option>
              </select>
            </div>

            {/* Combustibil */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Combustibil</label>
              <select 
                value={filters.fuel}
                onChange={(e) => handleInputChange('fuel', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="benzina">Benzină</option>
                <option value="diesel">Diesel</option>
                <option value="hybrid">Hibrid</option>
                <option value="electric">Electric</option>
                <option value="gpl">GPL</option>
                <option value="cng">CNG</option>
              </select>
            </div>

            {/* Județ/Regiune */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Județ/Regiune</label>
              <select 
                value={filters.region}
                onChange={(e) => handleInputChange('region', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="bucuresti">București</option>
                <option value="cluj">Cluj</option>
                <option value="timis">Timiș</option>
                <option value="constanta">Constanța</option>
                <option value="iasi">Iași</option>
                <option value="brasov">Brașov</option>
                <option value="galati">Galați</option>
                <option value="gorj">Gorj</option>
              </select>
            </div>

            {/* Localitate */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Localitate</label>
              <select 
                value={filters.locality}
                onChange={(e) => handleInputChange('locality', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-gray-100"
              >
                <option value="">Selectează</option>
                <option value="bucuresti">București</option>
                <option value="cluj-napoca">Cluj-Napoca</option>
                <option value="timisoara">Timișoara</option>
                <option value="constanta">Constanța</option>
              </select>
            </div>
          </div>

          {/* Caroserie */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Caroserie</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {categories.map((category) => (
                <label key={category.id} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.category.includes(category.id)}
                    onChange={() => handleCheckboxChange('category', category.id)}
                    className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                  />
                  <span className="text-sm text-gray-700 flex items-center gap-2">
                    <span className="text-lg">{category.icon}</span>
                    {category.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Additional Basic Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {/* Condiție */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Condiție</label>
              <select 
                value={filters.condition}
                onChange={(e) => handleInputChange('condition', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="nou">Nou</option>
                <option value="second-hand">Second hand</option>
                <option value="demonstrativ">Demonstrativ</option>
              </select>
            </div>

            {/* Cutie de viteze */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Cutie de viteze</label>
              <select 
                value={filters.gearbox}
                onChange={(e) => handleInputChange('gearbox', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="manuala">Manuală</option>
                <option value="automata">Automată</option>
                <option value="semiautomata">Semiautomată</option>
              </select>
            </div>

            {/* Tip vânzător */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Tip vânzător</label>
              <select 
                value={filters.seller}
                onChange={(e) => handleInputChange('seller', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="individual">Vânzător individual</option>
                <option value="dealer">Dealer</option>
                <option value="leasing">Companie leasing</option>
              </select>
            </div>
          </div>

          {/* Range Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            {/* An primă înmatriculare */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">An primă înmatriculare</label>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  placeholder="Min"
                  value={filters.yearMin}
                  onChange={(e) => handleInputChange('yearMin', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
                <input
                  type="number"
                  placeholder="Max"
                  value={filters.yearMax}
                  onChange={(e) => handleInputChange('yearMax', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>
            </div>

            {/* Preț */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Preț (EUR)</label>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  placeholder="Min"
                  value={filters.priceMin}
                  onChange={(e) => handleInputChange('priceMin', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
                <input
                  type="number"
                  placeholder="Max"
                  value={filters.priceMax}
                  onChange={(e) => handleInputChange('priceMax', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>
            </div>

            {/* Rulaj */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rulaj (km)</label>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <input
                  type="number"
                  value={filters.mileageMin}
                  onChange={(e) => handleInputChange('mileageMin', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
                <input
                  type="number"
                  value={filters.mileageMax}
                  onChange={(e) => handleInputChange('mileageMax', e.target.value)}
                  className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>
              {/* Slider visual representation */}
              <div className="relative">
                <div className="w-full h-2 bg-gray-200 rounded-full">
                  <div className="h-2 bg-red-600 rounded-full" style={{ width: '75%' }}></div>
                </div>
                <div className="flex justify-between mt-2 text-sm text-gray-500">
                  <span>0</span>
                  <span>180000</span>
                </div>
              </div>
            </div>

            {/* Additional Technical Filters */}
            <div className="space-y-4">
              {/* Cilindree */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cilindree (cm3)</label>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    placeholder="Min"
                    value={filters.cylinderMin}
                    onChange={(e) => handleInputChange('cylinderMin', e.target.value)}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={filters.cylinderMax}
                    onChange={(e) => handleInputChange('cylinderMax', e.target.value)}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                </div>
              </div>

              {/* Putere */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Putere (cp)</label>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    placeholder="Min"
                    value={filters.powerMin}
                    onChange={(e) => handleInputChange('powerMin', e.target.value)}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={filters.powerMax}
                    onChange={(e) => handleInputChange('powerMax', e.target.value)}
                    className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Additional Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">TVA</label>
              <select 
                value={filters.tva}
                onChange={(e) => handleInputChange('tva', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="deductibil">Deductibil</option>
                <option value="nedeductibil">Nedeductibil</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Discount</label>
              <select 
                value={filters.discount}
                onChange={(e) => handleInputChange('discount', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="da">Da</option>
                <option value="nu">Nu</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Lumini față</label>
              <select 
                value={filters.headlights}
                onChange={(e) => handleInputChange('headlights', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="halogen">Halogen</option>
                <option value="xenon">Xenon</option>
                <option value="led">LED</option>
                <option value="laser">Laser</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Pilot automat</label>
              <select 
                value={filters.autopilot}
                onChange={(e) => handleInputChange('autopilot', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="da">Da</option>
                <option value="nu">Nu</option>
              </select>
            </div>
          </div>

          {/* Color Sections */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Exterior Colors */}
            <div>
              <button
                onClick={() => toggleSection('exterior')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Exterior</h3>
                {expandedSections.exterior ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.exterior && (
                <div className="grid grid-cols-2 gap-3">
                  {exteriorColors.map((color) => (
                    <label key={color} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.exterior.includes(color)}
                        onChange={() => handleCheckboxChange('exterior', color)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                      />
                      <span className="text-sm text-gray-700">{color}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Interior Colors */}
            <div>
              <button
                onClick={() => toggleSection('interior')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Interior</h3>
                {expandedSections.interior ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.interior && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    {interiorColors.map((color) => (
                      <label key={color} className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={filters.interior.includes(color)}
                          onChange={() => handleCheckboxChange('interior', color)}
                          className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                        />
                        <span className="text-sm text-gray-700">{color}</span>
                      </label>
                    ))}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Material Interior</label>
                    <select 
                      value={filters.interiorMaterial}
                      onChange={(e) => handleInputChange('interiorMaterial', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    >
                      <option value="">Selectează</option>
                      {interiorMaterials.map((material) => (
                        <option key={material} value={material}>{material}</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Equipment Sections */}
          <div className="space-y-6 mb-8">
            {/* Dotări principale */}
            <div>
              <button
                onClick={() => toggleSection('mainEquipment')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Dotări principale</h3>
                {expandedSections.mainEquipment ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.mainEquipment && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {mainEquipmentOptions.map((option) => (
                    <label key={option} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.mainEquipment.includes(option)}
                        onChange={() => handleCheckboxChange('mainEquipment', option)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                      />
                      <span className="text-sm text-gray-700">{option}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Dotări siguranță */}
            <div>
              <button
                onClick={() => toggleSection('safetyEquipment')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Dotări siguranță</h3>
                {expandedSections.safetyEquipment ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.safetyEquipment && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {safetyEquipmentOptions.map((option) => (
                    <label key={option} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.safetyEquipment.includes(option)}
                        onChange={() => handleCheckboxChange('safetyEquipment', option)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                      />
                      <span className="text-sm text-gray-700">{option}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Dotări confort */}
            <div>
              <button
                onClick={() => toggleSection('comfortEquipment')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Dotări confort</h3>
                {expandedSections.comfortEquipment ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.comfortEquipment && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {comfortEquipmentOptions.map((option) => (
                    <label key={option} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.comfortEquipment.includes(option)}
                        onChange={() => handleCheckboxChange('comfortEquipment', option)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                      />
                      <span className="text-sm text-gray-700">{option}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Alte dotări */}
            <div>
              <button
                onClick={() => toggleSection('otherEquipment')}
                className="flex items-center justify-between w-full text-left mb-4"
              >
                <h3 className="text-lg font-semibold text-gray-900">Alte dotări</h3>
                {expandedSections.otherEquipment ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {expandedSections.otherEquipment && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {otherEquipmentOptions.map((option) => (
                    <label key={option} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.otherEquipment.includes(option)}
                        onChange={() => handleCheckboxChange('otherEquipment', option)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                      />
                      <span className="text-sm text-gray-700">{option}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Additional Specific Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Climatizare</label>
              <select 
                value={filters.climate}
                onChange={(e) => handleInputChange('climate', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="manuala">Manuală</option>
                <option value="automata">Automată</option>
                <option value="bizona">Bizonă</option>
                <option value="trizona">Trizonă</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Mod cuplare remorcă</label>
              <select 
                value={filters.trailerCoupling}
                onChange={(e) => handleInputChange('trailerCoupling', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="fix">Fix</option>
                <option value="detasabil">Detașabil</option>
                <option value="rabatabil">Rabatabil</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Asistent parcare</label>
              <select 
                value={filters.parkingAssist}
                onChange={(e) => handleInputChange('parkingAssist', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="senzori-fata">Senzori față</option>
                <option value="senzori-spate">Senzori spate</option>
                <option value="camera-marsarier">Cameră marșarier</option>
                <option value="parcare-automata">Parcare automată</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Trusă reparație</label>
              <select 
                value={filters.repairKit}
                onChange={(e) => handleInputChange('repairKit', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="da">Da</option>
                <option value="nu">Nu</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Airbag</label>
              <select 
                value={filters.airbag}
                onChange={(e) => handleInputChange('airbag', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="sofer">Șofer</option>
                <option value="pasager">Pasager</option>
                <option value="lateral">Lateral</option>
                <option value="cortina">Cortină</option>
                <option value="genunchi">Genunchi</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Radio</label>
              <select 
                value={filters.radio}
                onChange={(e) => handleInputChange('radio', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="am-fm">AM/FM</option>
                <option value="dab">DAB</option>
                <option value="internet">Internet</option>
                <option value="satelit">Satelit</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Etichetă emisii</label>
              <select 
                value={filters.emissionLabel}
                onChange={(e) => handleInputChange('emissionLabel', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">Selectează</option>
                <option value="euro6">Euro 6</option>
                <option value="euro5">Euro 5</option>
                <option value="euro4">Euro 4</option>
                <option value="euro3">Euro 3</option>
              </select>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t">
            <button className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-medium inline-flex items-center justify-center">
              <Filter className="w-5 h-5 mr-2" />
              Caută 17829 Autoturisme
            </button>
            <button 
              onClick={clearAllFilters}
              className="border border-gray-300 hover:bg-gray-50 text-gray-700 py-3 px-6 rounded-lg font-medium inline-flex items-center justify-center"
            >
              <X className="w-5 h-5 mr-2" />
              Șterge toate filtrele
            </button>
            <button 
              onClick={onBack}
              className="border border-gray-300 hover:bg-gray-50 text-gray-700 py-3 px-6 rounded-lg font-medium"
            >
              Înapoi la căutarea simplă
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedFilters;