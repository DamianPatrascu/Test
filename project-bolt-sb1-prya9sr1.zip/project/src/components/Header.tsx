import React from 'react';
import { Search, User, ChevronDown, Bell } from 'lucide-react';

interface HeaderProps {
  onHome?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onHome }) => {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 relative">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-xl sm:text-2xl font-bold text-red-600">
              PLUS-AUTO
              <span className="text-xs sm:text-sm font-normal text-gray-600 ml-1">marketplace</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden lg:flex space-x-8">
            <button 
              onClick={onHome}
              className="text-gray-700 hover:text-red-600 px-3 py-2 text-sm font-medium"
            >
              Acasă
            </button>
            <a href="#" className="text-gray-700 hover:text-red-600 px-3 py-2 text-sm font-medium">
              Autoturisme
            </a>
            <a href="#" className="text-gray-700 hover:text-red-600 px-3 py-2 text-sm font-medium">
              Motociclete
            </a>
            <a href="#" className="text-gray-700 hover:text-red-600 px-3 py-2 text-sm font-medium">
              Autoutilitare
            </a>
            <a href="#" className="text-gray-700 hover:text-red-600 px-3 py-2 text-sm font-medium">
              Altele
            </a>
          </nav>

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            <button className="hidden sm:block text-red-600 hover:text-red-700 text-sm font-medium">
              Publică anunț
            </button>
            
            <div className="hidden md:flex items-center space-x-2">
              <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">DP</span>
              </div>
              <span className="text-gray-700 text-sm">Damian Patrașcu</span>
              <ChevronDown className="w-4 h-4 text-gray-500" />
            </div>

            <div className="hidden sm:flex items-center space-x-1">
              <img 
                src="https://flagcdn.com/w20/ro.png" 
                alt="Romanian flag" 
                className="w-4 h-3"
              />
              <span className="text-sm text-gray-700">RO</span>
              <ChevronDown className="w-4 h-4 text-gray-500" />
            </div>

            {/* Mobile menu button */}
            <button className="lg:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;