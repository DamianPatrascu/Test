import React, { useState } from 'react';
import { Search, Filter, ChevronDown } from 'lucide-react';

interface HeroSectionProps {
  onAdvancedFilters?: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onAdvancedFilters }) => {
  const [selectedCategory, setSelectedCategory] = useState('Autoturisme');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <section className="bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8">
            Vinzi sau cumperi, cu noi ieși mereu pe Plus!
          </h1>
          
          <button 
            onClick={onAdvancedFilters}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium mb-8 inline-flex items-center"
          >
            <Filter className="w-5 h-5 mr-2" />
            Căutare cu filtre
          </button>

          {/* Search Bar */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg p-4 flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <select 
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white"
                >
                  <option value="Autoturisme">Autoturisme</option>
                  <option value="Motociclete">Motociclete</option>
                  <option value="Autoutilitare">Autoutilitare</option>
                  <option value="Altele">Altele</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
              </div>
              
              <div className="flex-2">
                <input
                  type="text"
                  placeholder="Caută mașina dorită..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>
              
              <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-medium inline-flex items-center">
                <Search className="w-5 h-5 mr-2" />
                Caută 17829 Autoturisme
              </button>
            </div>
          </div>
        </div>

        {/* Action Cards */}
        <div className="grid md:grid-cols-2 gap-8 mt-16">
          {/* Sell Card */}
          <div className="relative rounded-xl overflow-hidden shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-800 to-gray-600"></div>
            <img 
              src="https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=800" 
              alt="Car selling"
              className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
            />
            <div className="relative p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Vrei să vinzi o mașină?</h3>
              <div className="space-y-2 mb-6">
                <p className="text-gray-200">O poți vinde simplu și rapid dacă îndeplinești condițiile:</p>
                <p className="text-sm">Kilometraj: maxim 200000</p>
                <p className="text-sm">Vechime: maxim 10 ani</p>
                <p className="text-sm">Nu prezintă avarii la momentul publicării</p>
              </div>
              <button className="bg-white text-gray-900 hover:bg-gray-100 px-6 py-3 rounded-lg font-medium inline-flex items-center">
                Publică anunț
                <svg className="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>

          {/* Buy Card */}
          <div className="relative rounded-xl overflow-hidden shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-800 to-blue-600"></div>
            <img 
              src="https://images.pexels.com/photos/164634/pexels-photo-164634.jpeg?auto=compress&cs=tinysrgb&w=800" 
              alt="Car buying"
              className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
            />
            <div className="relative p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Vrei să cumperi o mașină?</h3>
              <div className="space-y-2 mb-6">
                <p className="text-gray-200">Am prefiltrat pentru tine anunțurile de calitate</p>
                <p className="text-sm">Mașini puțin rulate și sigure</p>
                <p className="text-sm">Istoric verificabil</p>
              </div>
              <button className="bg-white text-gray-900 hover:bg-gray-100 px-6 py-3 rounded-lg font-medium inline-flex items-center">
                Găsește-ți mașina perfectă
                <svg className="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;