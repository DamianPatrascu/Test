import React from 'react';
import { Heart, Eye, Calendar, Gauge, Fuel, Settings } from 'lucide-react';

interface CarCardProps {
  car: {
    id: number;
    title: string;
    price: number;
    netPrice: number;
    image: string;
    mileage: number;
    fuelType: string;
    transmission: string;
    engine: string;
    year: number;
    power: number;
    location: string;
    seller: string;
    isRecent: boolean;
    inStock: boolean;
    category: string;
  };
}

const CarCard: React.FC<CarCardProps> = ({ car }) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ro-RO', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(price).replace('EUR', '€');
  };

  const formatMileage = (mileage: number) => {
    return new Intl.NumberFormat('ro-RO').format(mileage);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow duration-200">
      <div className="relative">
        <img
          src={car.image}
          alt={car.title}
          className="w-full h-48 object-cover rounded-t-lg"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {car.isRecent && (
            <span className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
              Adăugat recent
            </span>
          )}
          {car.inStock && (
            <span className="bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
              În stoc
            </span>
          )}
        </div>

        {/* Heart Icon */}
        <button className="absolute top-3 right-3 bg-white rounded-full p-2 shadow-md hover:bg-gray-50">
          <Heart className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      <div className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{car.title}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span className="bg-gray-100 px-2 py-1 rounded text-xs">{car.category}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">{formatPrice(car.price)}</div>
            <div className="text-sm text-gray-500">{formatPrice(car.netPrice)} € NET</div>
          </div>
        </div>

        {/* Car Details */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4 text-sm">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{formatMileage(car.mileage)} km</span>
          </div>
          <div className="flex items-center gap-2">
            <Fuel className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{car.fuelType}</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{car.power} cp</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{car.transmission}</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{car.engine}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{car.year}</span>
          </div>
        </div>

        {/* Seller Info */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center text-sm text-gray-600 mb-4 gap-2">
          <div>
            <span className="text-red-600 font-medium">Vânzător individual</span>
            <span className="mx-2">|</span>
            <span>{car.location}</span>
          </div>
          <span className="text-gray-500">ID anunț: {car.id}</span>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2">
          <button className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium inline-flex items-center justify-center">
            Vezi detalii
            <svg className="w-4 h-4 ml-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
          <button className="flex-1 sm:flex-none border border-gray-300 hover:bg-gray-50 text-gray-700 py-2 px-4 rounded-lg font-medium">
            Contactează
          </button>
        </div>
      </div>
    </div>
  );
};

export default CarCard;