import React from 'react';
import { Phone } from 'lucide-react';
import Header from './Header';
import Breadcrumb from './Breadcrumb';
import CarCard from './CarCard';

interface SearchCriteria {
  color?: string;
  priceMin?: number;
  priceMax?: number;
  fuelType?: string;
  mileage?: number;
  year?: number;
}

interface SearchResultsProps {
  criteria: SearchCriteria;
  onHome: () => void;
  onBack: () => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ criteria, onHome, onBack }) => {
  // Sample car data with additional properties for filtering
  const allCars = [
    {
      id: 160344,
      title: "Mercedes-Benz GLC 300",
      price: 34700,
      netPrice: 29160,
      image: "https://images.pexels.com/photos/337909/pexels-photo-337909.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 135000,
      fuelType: "Hibrid",
      transmission: "Automată",
      engine: "1950 cm3",
      year: 2021,
      power: 306,
      location: "Târgu Jiu, Județul Gorj",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "SUV",
      color: "albastru"
    },
    {
      id: 160345,
      title: "Volkswagen Passat",
      price: 16999,
      netPrice: 14285,
      image: "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 87000,
      fuelType: "Benzină",
      transmission: "Automată",
      engine: "1798 cm3",
      year: 2017,
      power: 177,
      location: "București",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Berlină",
      color: "albastru"
    },
    {
      id: 160346,
      title: "BMW Serie 3 320d",
      price: 28500,
      netPrice: 23950,
      image: "https://images.pexels.com/photos/35967/mini-cooper-auto-model-vehicle.jpg?auto=compress&cs=tinysrgb&w=800",
      mileage: 95000,
      fuelType: "Diesel",
      transmission: "Automată",
      engine: "1995 cm3",
      year: 2019,
      power: 190,
      location: "București",
      seller: "Vânzător individual",
      isRecent: false,
      inStock: true,
      category: "Berlină",
      color: "negru"
    },
    {
      id: 160347,
      title: "Audi A6 Avant",
      price: 32000,
      netPrice: 26890,
      image: "https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 110000,
      fuelType: "Diesel",
      transmission: "Automată",
      engine: "2967 cm3",
      year: 2020,
      power: 231,
      location: "Cluj-Napoca",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Break",
      color: "albastru"
    },
    {
      id: 160348,
      title: "Toyota RAV4 Hybrid",
      price: 29800,
      netPrice: 25040,
      image: "https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 62000,
      fuelType: "Hibrid",
      transmission: "Automată",
      engine: "2487 cm3",
      year: 2022,
      power: 218,
      location: "Timișoara",
      seller: "Vânzător individual",
      isRecent: false,
      inStock: true,
      category: "SUV",
      color: "rosu"
    },
    {
      id: 160349,
      title: "Honda Civic Type R",
      price: 38900,
      netPrice: 32689,
      image: "https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 45000,
      fuelType: "Benzină",
      transmission: "Manuală",
      engine: "1996 cm3",
      year: 2021,
      power: 320,
      location: "Constanța",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Hatchback",
      color: "albastru"
    }
  ];

  // Filter cars based on criteria
  const filteredCars = allCars.filter(car => {
    // Color filter (always blue as specified)
    if (criteria.color && car.color !== criteria.color) {
      return false;
    }

    // Price filter
    if (criteria.priceMin && car.price < criteria.priceMin) {
      return false;
    }
    if (criteria.priceMax && car.price > criteria.priceMax) {
      return false;
    }

    // Fuel type filter
    if (criteria.fuelType && !car.fuelType.toLowerCase().includes(criteria.fuelType.toLowerCase())) {
      return false;
    }

    // Mileage filter (less than or equal to specified)
    if (criteria.mileage && car.mileage > criteria.mileage) {
      return false;
    }

    // Year filter (greater than or equal to specified)
    if (criteria.year && car.year < criteria.year) {
      return false;
    }

    return true;
  });

  const breadcrumbItems = [
    { label: 'Acasă', href: '#', onClick: onHome },
    { label: 'Autoturisme', href: '#', onClick: onBack },
    { label: 'Rezultate căutare', active: true }
  ];

  // Build search summary
  const buildSearchSummary = () => {
    const parts = [];
    if (criteria.color) parts.push(`culoare ${criteria.color}`);
    if (criteria.priceMin || criteria.priceMax) {
      if (criteria.priceMin && criteria.priceMax) {
        parts.push(`preț ${criteria.priceMin}€ - ${criteria.priceMax}€`);
      } else if (criteria.priceMin) {
        parts.push(`preț minim ${criteria.priceMin}€`);
      } else if (criteria.priceMax) {
        parts.push(`preț maxim ${criteria.priceMax}€`);
      }
    }
    if (criteria.fuelType) parts.push(`combustibil ${criteria.fuelType}`);
    if (criteria.mileage) parts.push(`rulaj maxim ${criteria.mileage.toLocaleString()} km`);
    if (criteria.year) parts.push(`an minim ${criteria.year}`);
    
    return parts.length > 0 ? parts.join(', ') : 'toate criteriile';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onHome={onHome} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Breadcrumb items={breadcrumbItems} />
        
        {filteredCars.length > 0 ? (
          <>
            {/* Results Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Rezultate căutare
              </h1>
              <p className="text-gray-600">
                Găsite {filteredCars.length} autoturisme pentru: {buildSearchSummary()}
              </p>
            </div>

            {/* Applied Filters */}
            <div className="bg-white rounded-lg shadow-sm border p-4 mb-8">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Filtre aplicate:</h3>
              <div className="flex flex-wrap gap-2">
                {criteria.color && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    Culoare: {criteria.color}
                  </span>
                )}
                {(criteria.priceMin || criteria.priceMax) && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Preț: {criteria.priceMin ? `${criteria.priceMin}€` : '0€'} - {criteria.priceMax ? `${criteria.priceMax}€` : '∞'}
                  </span>
                )}
                {criteria.fuelType && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Combustibil: {criteria.fuelType}
                  </span>
                )}
                {criteria.mileage && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    Rulaj max: {criteria.mileage.toLocaleString()} km
                  </span>
                )}
                {criteria.year && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                    An min: {criteria.year}
                  </span>
                )}
              </div>
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredCars.map((car) => (
                <CarCard key={car.id} car={car} />
              ))}
            </div>

            {/* Pagination */}
            <div className="mt-8 flex justify-center">
              <div className="flex items-center space-x-2">
                <button className="px-3 py-2 text-sm text-gray-500 hover:text-gray-700">Anterior</button>
                <button className="px-3 py-2 text-sm bg-red-600 text-white rounded">1</button>
                <button className="px-3 py-2 text-sm text-gray-700 hover:text-gray-900">Următorul</button>
              </div>
            </div>
          </>
        ) : (
          /* No Results Found */
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="max-w-md mx-auto">
              <div className="mb-8">
                <svg className="w-24 h-24 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.29-1.009-5.824-2.562M15 6.306a7.962 7.962 0 00-6 0m6 0V4a2 2 0 00-2-2h-2a2 2 0 00-2 2v2.306" />
                </svg>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Nu am găsit rezultate
                </h2>
                <p className="text-lg text-gray-600 mb-2">
                  Se pare că nu avem ceea ce cauți în stoc.
                </p>
                <p className="text-lg text-gray-600 mb-8">
                  Dar poți să ne suni direct. Poate te putem ajuta să găsești ceea ce cauți.
                </p>
              </div>

              {/* Phone Contact */}
              <div className="bg-white rounded-lg shadow-sm border p-6">
                <div className="flex items-center justify-center mb-4">
                  <Phone className="w-8 h-8 text-red-600 mr-3" />
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Sună-ne acum</p>
                    <a 
                      href="tel:+40721234567" 
                      className="text-2xl font-bold text-red-600 hover:text-red-700 transition-colors"
                    >
                      +40 721 234 567
                    </a>
                  </div>
                </div>
                <p className="text-sm text-gray-500">
                  Program: Luni - Vineri, 09:00 - 18:00
                </p>
              </div>

              {/* Search Criteria Summary */}
              <div className="mt-8 p-4 bg-gray-100 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Ai căutat:</p>
                <p className="text-sm font-medium text-gray-800">{buildSearchSummary()}</p>
              </div>

              {/* Action Buttons */}
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={onBack}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-medium transition-colors"
                >
                  Modifică căutarea
                </button>
                <button
                  onClick={onHome}
                  className="flex-1 border border-gray-300 hover:bg-gray-50 text-gray-700 py-3 px-6 rounded-lg font-medium transition-colors"
                >
                  Înapoi la început
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;