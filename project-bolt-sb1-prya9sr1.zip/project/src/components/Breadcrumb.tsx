import React from 'react';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbProps {
  items: Array<{
    label: string;
    href?: string;
    onClick?: () => void;
    active?: boolean;
  }>;
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
      {items.map((item, index) => (
        <div key={index} className="flex items-center">
          {index > 0 && (
            <ChevronRight className="w-4 h-4 mx-2 text-gray-400" />
          )}
          {item.active ? (
            <span className="text-gray-900 font-medium">{item.label}</span>
          ) : (
            item.onClick ? (
              <button
                onClick={item.onClick}
                className="text-red-600 hover:text-red-700 hover:underline"
              >
                {item.label}
              </button>
            ) : (
              <a 
                href={item.href || '#'} 
                className="text-red-600 hover:text-red-700 hover:underline"
              >
                {item.label}
              </a>
            )
          )}
        </div>
      ))}
    </nav>
  );
};

export default Breadcrumb;