import React from 'react';
import { ChevronDown } from 'lucide-react';
import CarCard from './CarCard';

const CarListings = () => {
  const cars = [
    {
      id: 160344,
      title: "Mercedes-Benz GLC 300",
      price: 34700,
      netPrice: 29160,
      image: "https://images.pexels.com/photos/337909/pexels-photo-337909.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 135000,
      fuelType: "Hibrid (D/E)",
      transmission: "Automată",
      engine: "1950 cm3",
      year: 2021,
      power: 306,
      location: "Târgu Jiu, Județul Gorj",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "SUV"
    },
    {
      id: 160345,
      title: "Volkswagen Passat",
      price: 16999,
      netPrice: 14285,
      image: "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 87000,
      fuelType: "Benzină",
      transmission: "Automată",
      engine: "1798 cm3",
      year: 2017,
      power: 177,
      location: "Berlină",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Berlină"
    },
    {
      id: 160346,
      title: "BMW Serie 3 320d",
      price: 28500,
      netPrice: 23950,
      image: "https://images.pexels.com/photos/35967/mini-cooper-auto-model-vehicle.jpg?auto=compress&cs=tinysrgb&w=800",
      mileage: 95000,
      fuelType: "Diesel",
      transmission: "Automată",
      engine: "1995 cm3",
      year: 2019,
      power: 190,
      location: "București",
      seller: "Vânzător individual",
      isRecent: false,
      inStock: true,
      category: "Berlină"
    },
    {
      id: 160347,
      title: "Audi A6 Avant",
      price: 32000,
      netPrice: 26890,
      image: "https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 110000,
      fuelType: "Diesel",
      transmission: "Automată",
      engine: "2967 cm3",
      year: 2020,
      power: 231,
      location: "Cluj-Napoca",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Break"
    },
    {
      id: 160348,
      title: "Toyota RAV4 Hybrid",
      price: 29800,
      netPrice: 25040,
      image: "https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 62000,
      fuelType: "Hibrid",
      transmission: "Automată",
      engine: "2487 cm3",
      year: 2022,
      power: 218,
      location: "Timișoara",
      seller: "Vânzător individual",
      isRecent: false,
      inStock: true,
      category: "SUV"
    },
    {
      id: 160349,
      title: "Honda Civic Type R",
      price: 38900,
      netPrice: 32689,
      image: "https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=800",
      mileage: 45000,
      fuelType: "Benzină",
      transmission: "Manuală",
      engine: "1996 cm3",
      year: 2021,
      power: 320,
      location: "Constanța",
      seller: "Vânzător individual",
      isRecent: true,
      inStock: true,
      category: "Hatchback"
    }
  ];

  return (
    <div className="flex-1">
      {/* Results Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-lg sm:text-xl font-semibold text-gray-900">Afișează de la 1 la 10 din 17829 rezultate</h2>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2">
          <span className="hidden sm:block text-sm text-gray-600">Sortare recomandată</span>
          <div className="relative">
            <select className="p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white pr-8">
              <option>Sortare recomandată</option>
              <option>Preț crescător</option>
              <option>Preț descrescător</option>
              <option>Anul fabricației</option>
              <option>Kilometraj</option>
              <option>Data adăugării</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Car Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {cars.map((car) => (
          <CarCard key={car.id} car={car} />
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-8 flex justify-center">
        <div className="flex items-center space-x-1 sm:space-x-2 text-sm">
          <button className="px-3 py-2 text-sm text-gray-500 hover:text-gray-700">Anterior</button>
          <button className="px-3 py-2 text-sm bg-red-600 text-white rounded">1</button>
          <button className="px-3 py-2 text-sm text-gray-700 hover:text-gray-900">2</button>
          <button className="px-3 py-2 text-sm text-gray-700 hover:text-gray-900">3</button>
          <button className="hidden sm:block px-3 py-2 text-sm text-gray-700 hover:text-gray-900">4</button>
          <button className="hidden sm:block px-3 py-2 text-sm text-gray-700 hover:text-gray-900">5</button>
          <span className="hidden sm:block px-3 py-2 text-sm text-gray-500">...</span>
          <button className="hidden sm:block px-3 py-2 text-sm text-gray-700 hover:text-gray-900">178</button>
          <button className="px-3 py-2 text-sm text-gray-500 hover:text-gray-700">Următorul</button>
        </div>
      </div>
    </div>
  );
};

export default CarListings;